package ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityMainBinding
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var reg: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        reg = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(reg.root)

        val regname = "welcome, " + reg.regname.text.toString().trim() + "!"


        reg.submit.setOnClickListener{

            if(reg.regname.text.isNullOrBlank()) {
                Toast.makeText(this, "please fill in fields", Toast.LENGTH_SHORT)
            }
            else{

                val intent = Intent(this, HomeActivity::class.java).also{
                    it.putExtra("message", regname)
                }
                startActivity(intent)
                finish()
            }
        }
    }
}