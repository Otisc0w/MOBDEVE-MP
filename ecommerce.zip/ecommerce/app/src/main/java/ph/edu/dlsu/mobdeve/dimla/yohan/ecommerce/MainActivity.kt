package ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var main: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        main = ActivityMainBinding.inflate(layoutInflater)
        setContentView(main.root)

        main.login.setOnClickListener{

            val uname = "welcome, " + main.editTextTextEmailAddress.text.toString().trim() + "!"
            val pass = main.editTextTextPassword.text.toString().trim()

            if(main.editTextTextEmailAddress.text.isNullOrBlank()) {
                Toast.makeText(this, "please fill in fields", Toast.LENGTH_SHORT)
            }
            else{

                val intent = Intent(this, HomeActivity::class.java).also{
                    it.putExtra("msg", uname)
                }
                startActivity(intent)
                finish()
            }

        }

        main.register.setOnClickListener{

                val intent = Intent(this, RegisterActivity::class.java)

                startActivity(intent)
                finish()


        }

    }
}