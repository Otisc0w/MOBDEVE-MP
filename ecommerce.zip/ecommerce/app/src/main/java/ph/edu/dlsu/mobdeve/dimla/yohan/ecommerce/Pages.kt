package ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityCarPageBinding
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityGlowPageBinding
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityHeadPageBinding

class GlowPage : AppCompatActivity() {

    private lateinit var net: ActivityGlowPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        net = ActivityGlowPageBinding.inflate(layoutInflater)
        setContentView(net.root)

        var x=1
        net.glow.setOnClickListener{
            if(x%2<1)
                net.glow.setImageResource(R.drawable.hoop2)
            else{
                net.glow.setImageResource(R.drawable.hoop1)
            }

            x++

        }
    }
}

class CarPage : AppCompatActivity() {

    private lateinit var car: ActivityCarPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        car = ActivityCarPageBinding.inflate(layoutInflater)
        setContentView(car.root)

        var x=1
        car.porsche.setOnClickListener{
            if(x%2<1)
                car.porsche.setImageResource(R.drawable.car2)
            else{
                car.porsche.setImageResource(R.drawable.car1)
            }

            x++

        }
    }
}

class HeadPage : AppCompatActivity() {

    private lateinit var head: ActivityHeadPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        head = ActivityHeadPageBinding.inflate(layoutInflater)
        setContentView(head.root)

        var x=1
        head.helmet.setOnClickListener{
            if(x%2<1)
                head.helmet.setImageResource(R.drawable.head2)
            else{
                head.helmet.setImageResource(R.drawable.head1)
            }

            x++

        }
    }
}