package ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import ph.edu.dlsu.mobdeve.dimla.yohan.ecommerce.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var home: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(home.root)

        val message = intent.getStringExtra("msg")
        val mess = intent.getStringExtra("message")
        val textView = findViewById<TextView>(R.id.helloview).apply{
            if(message.isNullOrBlank())
                text = mess
            else
                text=message

        }

        home.carclick.setOnClickListener{

            val intent = Intent(this, CarPage::class.java)
            startActivity(intent)

        }

        home.headclick.setOnClickListener{

            val intent = Intent(this, HeadPage::class.java)
            startActivity(intent)

        }

        home.netclick.setOnClickListener{

            val intent = Intent(this, GlowPage::class.java)
            startActivity(intent)

        }


    }


}